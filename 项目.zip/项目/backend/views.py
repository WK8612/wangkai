# -*- coding: utf-8 -*-
'''
web视图
'''
from flask import (
    url_for, request,
    render_template, render_template_string
)

from . import app


@app.route(r'/', methods=['GET'])
def view_index():
    return render_template('index.html')
