# -*- coding: utf-8 -*-
'''
后端主入口
'''
from . import app
from . import views
from . import config


app.config['SECRET_KEY'] = config.SECRET_KEY

def start_server():
    '''启动web服务'''
    # 配置调试模式
    is_debug = config.RUN_CFG.get('debug', False)
    if is_debug:
        app.debug = True
    # 运行web服务器
    app.run(**config.RUN_CFG)