# -*- coding: utf-8 -*-
'''
配置
'''
import os


# session密钥
SECRET_KEY = 'hello mini demo'
# 运行配置
RUN_CFG = {
    'host': '127.0.0.1',
    'port': 5000,
    'debug': True
}